import unittest
import placar

class TestPlacar(unittest.TestCase):

    def setUp(self):
        self.p1 = placar.Placar()
        
    def test_conta(self):
        self.assertEqual(self.p1.conta(1, [1, 1, 3, 3, 3]), 2)
        self.assertEqual(self.p1.conta(3, [1, 2, 4, 5, 6]), 0)
        self.assertEqual(self.p1.conta(1, [1, 1, 1, 1, 1]), 5)

    def test_full_house_true(self):
        self.assertTrue(self.p1.checkFull([3,3,3,2,2]))
        self.assertTrue(self.p1.checkFull([1,1,1,1,1]))
        self.assertTrue(self.p1.checkFull([1,1,5,5,5]))
    
    def test_full_house_false(self):
        self.assertFalse(self.p1.checkFull([1,2,3,4,2]))
        self.assertFalse(self.p1.checkFull([1,1,1,1,3]))
        self.assertFalse(self.p1.checkFull([1,1,3,5,5]))

    